//= require redactor-rails/redactor.min
//= require redactor-rails/langs/pt_br
//= require ./redactor-rails/video.js
//= require ./redactor-rails/config.js

