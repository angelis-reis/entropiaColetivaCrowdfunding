class ProjectTotal < ActiveRecord::Base
end
